package com.example.social_media_app

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
